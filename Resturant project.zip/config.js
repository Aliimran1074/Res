  import { initializeApp } from "https://www.gstatic.com/firebasejs/10.7.1/firebase-app.js";

  const firebaseConfig = {
    apiKey: "AIzaSyDruOFpxfBKpCAQ47cC_ZaqsFQValoU4_o",
    authDomain: "hackaton-practice-b6221.firebaseapp.com",
    projectId: "hackaton-practice-b6221",
    storageBucket: "hackaton-practice-b6221.appspot.com",
    messagingSenderId: "585341210955",
    appId: "1:585341210955:web:6c2c4b93e69bc2185b18ce",
    measurementId: "G-PJM2W5VZGQ"
  };


  const app = initializeApp(firebaseConfig);

  export {app}
